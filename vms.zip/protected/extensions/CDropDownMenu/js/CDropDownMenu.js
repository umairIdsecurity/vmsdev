$(document).ready(function() { 
		$('ul.sf-menu').superfish();
	}); 
