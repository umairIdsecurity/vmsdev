<?php
/* @var $this LicenseDetailsController */
/* @var $model LicenseDetails */


?>

<h1>Update License Details </h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>