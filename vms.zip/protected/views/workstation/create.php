<?php
/* @var $this WorkstationController */
/* @var $model Workstation */

?>

<h1>Create Workstation</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>