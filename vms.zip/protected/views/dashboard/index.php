<?php
/* @var $this DashboardController */
/* @var $dataProvider CActiveDataProvider */


?>

<h1>Dashboard</h1>

Dashboard page is not yet implemented.
