<?php
/* @var $this UserWorkstationsController */
/* @var $model UserWorkstations */

?>

<h1>Update UserWorkstations <?php echo $model->id; ?></h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>