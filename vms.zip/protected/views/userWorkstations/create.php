<?php
/* @var $this UserWorkstationsController */
/* @var $model UserWorkstations */

?>

<h1>Create UserWorkstations</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>