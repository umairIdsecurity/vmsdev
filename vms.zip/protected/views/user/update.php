<?php
/* @var $this UserController */
/* @var $model User */


?>

<h1>Update User</h1>

<?php $this->renderPartial('_form', array('model'=>$model)); ?>